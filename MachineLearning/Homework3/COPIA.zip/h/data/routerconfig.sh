#!/usr/bin/env sh
set -e

# Copy default config files
cp routerconfig.conf /config/routerconfig.conf

# Ensure lease db exists
touch /config/routerconfig.leases

exec "$@"
