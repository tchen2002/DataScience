#!/usr/bin/env sh
set -e

# Copy default config files
cp dhcpd.conf /config/dhcpd.conf

# Ensure lease db exists
touch /config/dhcpd.leases

exec "$@"
