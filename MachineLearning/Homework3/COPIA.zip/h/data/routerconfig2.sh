#!/usr/bin/env sh
set -e

# Copy default config files
cp routerconfig2.conf /config/routerconfig2.conf

# Ensure lease db exists
touch /config/routerconfig2.leases

exec "$@"
