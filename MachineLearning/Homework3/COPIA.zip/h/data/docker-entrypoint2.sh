#!/usr/bin/env sh
set -e

# Copy default config files
cp dhcpd2.conf /config/dhcpd2.conf

# Ensure lease db exists
touch /config/dhcpd2.leases

exec "$@"
