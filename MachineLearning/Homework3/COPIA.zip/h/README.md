# 202201-IC7602-Proyecto

# Run the project

- Make build 
- docker-compose up

# Stop and Delete Containers

- Make stop 

# Delete images 

- Make delete 