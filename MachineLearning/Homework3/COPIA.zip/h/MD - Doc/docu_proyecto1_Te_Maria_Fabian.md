# Instituto Tecnológico de Costa Rica
# Proyecto #1
#### Te Chen Huang - 2019033478
#### Maria Jose Barquero - 2019037947
#### Fabian Vives Castro - 2018319257

### Instrucciones para ejecutar el proyecto tomando en cuenta que se instala desde el sistema operativo Linux.

1. Instale Docker y Docker compose
2. Clone el repositorio del proyecto, tener en cuenta que esta dirección es copiada desde el método ssh

     git clone git@github.com:tchen2002/202201-IC7602-Proyecto1.git

3. O bien puede descargar desde el repositorio el archivo como un zip.
4. Se cuenta con un Makefile el cual realizará todo el trabajo de creación de contenedores. Por lo que hay las siguientes posibilidades:
     
    - make build -> Crear los contenedores, imagenes, redes 
    - make stop ->  Detiene el proyecto y elimina contenedores y redes
    - make delete ->  Elimina las imágenes creadas anteriormente 
5. Para correr el proyecto solo se necesita escribir en la terminal make build y cuando este finalice debe escribir el comando docker-compose up de esta manera ya la red se estará corriendo para realizar las pruebas que sean necesarias. 

Nota: Para que el makefile funcione se debe eliminar el siguiente file cada vez que se desea correr

![Imagen 1](ima1.jpg)


### Pruebas realizadas, con pasos para reproducirlas.

Para las pruebas que realizamos entramos al cliente de la siguiente manera: docker container exec -it client1 sh

Con ip addr podemos ver como el dhcp le da la ip 10.0.0.100 la cual es la primera ip del rango configurado por dhcp al igual que el broadcast que se agrega. 

![Imagen 2](ima2.jpg)


Con ping verificamos que los paquetes de la ip de lleguen, c3 es la cantidad de paquetes enviados. 

![Imagen 3](ima3.jpg)

Tambien utilizamos nslookup, pero con este se tiene problemas ya que el server es 127.0.0.0.

![Imagen 3](ima4.jpg)

Para el nombre de dominio realizamos la misma prueba pero tuvimos el siguiente problema: 

![Imagen 3](ima5.jpg)
Investigando el error creemos que se debe a la imagen que se está utilizando para el cliente.  


### Recomendaciones 
1. Como recomendaciones para futuros estudiantes que vayan a realizar este proyecto o un proyecto similar realizamos la siguiente lista:

2. Empezar a entender el proyecto desde el día uno, a pesar de tener tanto tiempo para desarrollarlo, es un proyecto grande que necesita sentarse a pensar y entender cómo funciona la red.

3. Aprovechar todos los recursos que el profesor da, ya sean horas de consulta, links donde vienen algunas configuraciones.
Creemos que el orden para empezar sería buscar crear el docker-compose.yaml con el dhcp, en el dhcp tener en cuenta que este debe estar enlazado a un network de lo contrario mostrará un error.

4. Utilizar Docker Hub para buscar imágenes como referencia, estas traen el repositorio de Github por lo que uno se puede basar en estas configuraciones para realizar la red
5. Se puede utilizar el driver macvlan para la creación de redes esta nos funcionó bien para esta parte
6. No dejarlo para el final, ya que se invierten gran cantidad de horas investigando y tratando de arreglar errores, por lo que es bueno empezarlo desde el inicio para poder cubrir la mayor parte del proyecto.
7. Este proyecto se presta mucho para permitir dividir las configuraciones entre diferentes personas del equipo una recomendación sería una persona dhcp y cliente, otra dns y otra router. Cuando esto se esté terminando de configurar se puede enfocar en las demás configuraciones. 
8. Tener bastante comunicación entre los participantes del equipo para avanzar lo más rápido posible. 
9. Utilizar herramientas como github donde permite tener las versiones que se van utilizando de código, una recomendación que no realizamos y creemos es de gran utilidad es haber realizado una rama por cada configuración solicitada.
10. Ir documentando las páginas que se van buscando en internet, tal vez un documento en drive compartido con los demás integrantes del equipo donde se muestre este comando funciono intente esto otro pero tira tal error, para llevar un registro y tener un control de estos.

### Conclusiones 

Para concluir nuestro equipo piensa que es necesario aprender la correcta utilización de los puertos, ya que si este no se ha configurado correctamente para mantener abierto, la conexión será rechazada.

Ya que Docker se ejecuta dentro de un contenedor, y el contenedor se puede ejecutar en cualquier sistema operativo que tenga Docker instalado, a la hora de existir algún tipo de error, usualmente el error fue presenciado anteriormente por algún miembro del equipo, por lo que gracias a Docker, la resolucion de error en dado problema fue rápido de resolver.

En el caso de cambiar el dns por defecto a los web servers, se recomienda en el entrypoint detener el servicio, usando nginx, cambiar el dns por defecto del servidor, y volver a iniciar el servicio.

Entre las imágenes que se investigaron para realizar el dhcp nos basamos en un repositorio de github donde la mayoría de la configuración se amoldaba a las especificaciones, uno de los retos más grandes con DHCP fue el error de no encontrar el ip que se asignaba (10.0.0.4), por lo que nos dimos cuenta que este debe estar conectado a una red 10.0.0.0/24 para poder ser encontrada. 

Se utilizó network macvlan ya que este conecta las interfaces del contenedor directamente a las interfaces del host. Los contenedores se direccionan con direcciones IP enrutables que se encuentran en la subred de la red.
Con la ejecución de este proyecto a pesar de no completarlo, reforzamos nuestro conocimientos en docker y docker compose, además pusimos en práctica mucho de lo visto en clase lo cual ayuda a entender de una mejor manera. Todo esto lo solemos ignorar cuando usamos la red de nuestra casa, damos por hecho el funcionamiento de este, pero lo que hay por debajo es un proceso muy complejo el cual gracias a este proyecto logramos comprender de una mejor manera. 

Como equipo tomamos decisiones que nos permitieron poder avanzar más con el proyecto, por ejemplo la división de tareas entre cada uno de los integrantes. Parte del aprendizaje que tuvimos con la realización de este proyecto es lo importante de la comunicación entre los miembros de trabajo, la organización y además es muy importante iniciar desde la primera semana a comprender e investigar para obtener el mejor resultado posible. 

Antes de utilizar alguna imagen base para cualquier trabajo, es muy importante leer y ver como fue que se implementó, analizar las restricciones, sus ventajas y desventajas al usar la imagen.

Para la parte de VPN, es muy importante entender la relación que tiene VPN con otros componentes antes de realizar la implementación, debido a qué en internet hay imagenes creadas de openvp, pero sin entender la parte básica puede complicar en el proyecto.

Para finalizar, a pesar de que el proyecto no se pudo completar en su totalidad sentimos que si pudimos aprender y entender mejor los componentes a través de las documentaciones. Del mismo modo, pudimos usar docker por primera vez en un proyecto.

### Referencias 

- debgleros-old. (2020). udhcpc. https://github.com/dengleros-old/udhcpc
- Jeremy Canfield. (Dec 10, 2021).  DHCP - Install DHCPD on Docker. http://www.freekb.net/Article?id=3354
- wastrachan. (2021). docker-dhcpd. https://github.com/wastrachan/docker-dhcpd
- Luke B. (Oct 1, 2018). Setup BIND9 with ISC-DHCP-SERVER dynamic host registration. https://www.talk-about-it.ca/setup-bind9-with-isc-dhcp-server-dynamic-host-registration/
- Zytrax.open (s.f.).  BIND 9 Support DNS BIND controls clause. https://www.zytrax.com/books/dns/ch7/controls.html
- Rapid7. (Mar 4, 2014). How To Run Rsyslog in a Docker Container for Logging. https://www.rapid7.com/blog/post/2014/03/04/how-to-run-rsyslog-in-a-docker-container-for-logging
- kylemanna. (2020). docker-openvpn. https://github.com/kylemanna/docker-openvpn
- Justin Ellingwood. (July 1, 2014) How To Configure Bind as a Caching or Forwarding DNS Server on Ubuntu 14.04. https://www.digitalocean.com/community/tutorials/how-to-configure-bind-as-a-caching-or-forwarding-dns-server-on-ubuntu-14-04
- Derek Seaman. (June 9,2019). How-to: OpenVPN Server in a Synology Docker Container. https://www.derekseaman.com/2019/06/how-to-synology-openvpn-server-in-a-docker-container.html
- OpenVPN. (2022). openvpn. https://github.com/OpenVPN/openvpn

